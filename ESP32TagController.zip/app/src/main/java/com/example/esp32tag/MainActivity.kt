package com.example.esp32tag

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.ParcelUuid
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.esp32tag.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val SERVICE_UUID = UUID.fromString("0000abcd-0000-1000-8000-00805f9b34fb")
    private val CHAR_UUID    = UUID.fromString("0000dcba-0000-1000-8000-00805f9b34fb")

    private lateinit var bluetoothAdapter: BluetoothAdapter
    private var scanner: BluetoothLeScanner? = null
    private var scanning = false
    private val scanResults = mutableListOf<ScanResult>()
    private var gatt: BluetoothGatt? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        scanner = bluetoothAdapter.bluetoothLeScanner

        binding.rvDevices.layoutManager = LinearLayoutManager(this)
        binding.rvDevices.adapter = DevicesAdapter(scanResults) { res -> connect(res.device) }

        binding.btnScan.setOnClickListener { ensurePermsThenScan() }
        binding.btnLightOn.setOnClickListener { writeCmd(0x01) }
        binding.btnLightOff.setOnClickListener { writeCmd(0x02) }
        binding.btnBuzzerOn.setOnClickListener { writeCmd(0x03) }
        binding.btnBuzzerOff.setOnClickListener { writeCmd(0x04) }

        setStatus("Desconectado")
    }

    private fun setStatus(text: String) {
        binding.tvStatus.text = "Estado: $text"
    }

    private fun ensurePermsThenScan() {
        val perms = arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        )
        val missing = perms.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permLauncher.launch(missing.toTypedArray())
        } else {
            startScan()
        }
    }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res ->
        if (res.values.all { it }) startScan() else setStatus("Permisos denegados")
    }

    private fun startScan() {
        if (scanning) return
        scanResults.clear()
        binding.rvDevices.adapter?.notifyDataSetChanged()

        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()

        scanner?.startScan(listOf(filter), settings, scanCb)
        scanning = true
        setStatus("Buscando ESP32...")
        binding.rvDevices.postDelayed({ stopScan() }, 10000)
    }

    private fun stopScan() {
        if (!scanning) return
        scanner?.stopScan(scanCb)
        scanning = false
        setStatus("Escaneo detenido")
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            runOnUiThread {
                if (scanResults.none { it.device.address == result.device.address }) {
                    scanResults.add(result)
                    binding.rvDevices.adapter?.notifyItemInserted(scanResults.size - 1)
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { setStatus("Scan falló: $errorCode") }
        }
    }

    private fun connect(device: BluetoothDevice) {
        setStatus("Conectando a ${device.address}...")
        gatt?.close()
        gatt = device.connectGatt(this, false, gattCb)
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { setStatus("Conectado. Descubriendo servicios...") }
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread { setStatus("Desconectado") }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                val svc = g.getService(SERVICE_UUID)
                runOnUiThread {
                    if (svc != null) setStatus("Servicio encontrado")
                    else setStatus("Servicio no encontrado")
                }
            } else {
                runOnUiThread { setStatus("Discover failed: $status") }
            }
        }
    }

    private fun writeCmd(byte: Int) {
        val g = gatt ?: return setStatus("No conectado")
        val svc = g.getService(SERVICE_UUID) ?: return setStatus("Servicio no disponible")
        val ch = svc.getCharacteristic(CHAR_UUID) ?: return setStatus("Característica no disponible")
        ch.value = byteArrayOf(byte.toByte())
        val ok = g.writeCharacteristic(ch)
        setStatus(if (ok) "Comando enviado" else "Escritura falló")
    }

    override fun onDestroy() {
        gatt?.close()
        gatt = null
        super.onDestroy()
    }
}